#include "ps2_audio_system.h"
#include "fmod/fmod.h"
#include "ps2/ps2_utils.h"
#include "utils.h"

#include "stdio_compat.h"
#include <stdlib.h>
#include "string_compat.h"
#include <inttypes.h>
#include <math.h>
#include <audsrv.h>

// ===[ IMA ADPCM Tables ]===

static const int16_t IMA_STEP_TABLE[89] = {
    7, 8, 9, 10, 11, 12, 13, 14,
    16, 17, 19, 21, 23, 25, 28, 31,
    34, 37, 41, 45, 50, 55, 60, 66,
    73, 80, 88, 97, 107, 118, 130, 143,
    157, 173, 190, 209, 230, 253, 279, 307,
    337, 371, 408, 449, 494, 544, 598, 658,
    724, 796, 876, 963, 1060, 1166, 1282, 1411,
    1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024,
    3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484,
    7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,
    15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
    32767
};

static const int8_t IMA_INDEX_TABLE[16] = {
    -1, -1, -1, -1, 2, 4, 6, 8,
    -1, -1, -1, -1, 2, 4, 6, 8
};

// ===[ IMA ADPCM Decoder ]===

// Decode a block of IMA ADPCM data, updating predictor/stepIndex state in place
// Returns the number of samples written to outPcm (2 per input byte)
static uint32_t imaAdpcmDecodeBlock(const uint8_t* adpcmData, uint32_t adpcmSize, int16_t* outPcm, int32_t* predictor, int32_t* stepIndex) {
    uint32_t samplesWritten = 0;

    repeat(adpcmSize, i) {
        uint8_t byte = adpcmData[i];

        // Process two nibbles per byte (low nibble first, then high)
        for (int nibbleIdx = 0; 2 > nibbleIdx; nibbleIdx++) {
            uint8_t nibble = (nibbleIdx == 0) ? (byte & 0x0F) : ((byte >> 4) & 0x0F);

            int32_t step = IMA_STEP_TABLE[*stepIndex];
            int32_t delta = step >> 3;
            if (nibble & 1) delta += step >> 2;
            if (nibble & 2) delta += step >> 1;
            if (nibble & 4) delta += step;
            if (nibble & 8) delta = -delta;

            *predictor += delta;
            if (*predictor > 32767) *predictor = 32767;
            if (-32768 > *predictor) *predictor = -32768;

            *outPcm++ = (int16_t) *predictor;
            samplesWritten++;

            *stepIndex += IMA_INDEX_TABLE[nibble];
            if (0 > *stepIndex) *stepIndex = 0;
            if (*stepIndex > 88) *stepIndex = 88;
        }
    }

    return samplesWritten;
}

// Convenience wrapper for full-buffer decode (SFX path)
static void imaAdpcmDecode(const uint8_t* adpcmData, uint32_t adpcmSize, int16_t* outPcm) {
    int32_t predictor = 0;
    int32_t stepIndex = 0;
    imaAdpcmDecodeBlock(adpcmData, adpcmSize, outPcm, &predictor, &stepIndex);
}

// ===[ SOUNDBNK.BIN Parser ]===

static void parseSoundBank(Ps2AudioSystem* ps2) {
    char* path = PS2Utils_createDevicePath("SOUNDBNK.BIN");

    FILE* f = fopen(path, "rb");
    free(path);
    if (f == nullptr) {
        logWarn("PS2AudioSystem: Could not open SOUNDBNK.BIN\n");
        return;
    }

    // Header: version(u8) + sondEntryCount(u16) + audoEntryCount(u16) + musEntryCount(u16) = 7 bytes
    uint8_t version;
    fread(&version, 1, 1, f);
    fread(&ps2->sondEntryCount, 2, 1, f);
    fread(&ps2->audoEntryCount, 2, 1, f);
    fread(&ps2->musEntryCount, 2, 1, f);

    logInfo("PS2AudioSystem: SOUNDBNK v%d, %d SOND entries, %d AUDO entries, %d MUS entries\n", version, ps2->sondEntryCount, ps2->audoEntryCount, ps2->musEntryCount);

    // Parse SOND entries (12 bytes each)
    ps2->sondEntries = safeMalloc(ps2->sondEntryCount * sizeof(Ps2SondEntry));
    for (int i = 0; ps2->sondEntryCount > i; i++) {
        uint8_t buf[12];
        fread(buf, 12, 1, f);
        ps2->sondEntries[i].audoIndex = *(uint16_t*) &buf[0];
        ps2->sondEntries[i].flags     = *(uint32_t*) &buf[2];
        ps2->sondEntries[i].volume    = *(int16_t*)  &buf[6];
        ps2->sondEntries[i].pitch     = *(int16_t*)  &buf[8];
        // buf[10..11] reserved
    }

    // Parse AUDO entries (20 bytes each)
    ps2->audoEntries = safeMalloc(ps2->audoEntryCount * sizeof(Ps2AudoEntry));
    for (int i = 0; ps2->audoEntryCount > i; i++) {
        uint8_t buf[20];
        fread(buf, 20, 1, f);
        ps2->audoEntries[i].dataOffset    = *(uint32_t*) &buf[0];
        ps2->audoEntries[i].dataSize      = *(uint32_t*) &buf[4];
        ps2->audoEntries[i].sampleRate    = *(uint16_t*) &buf[8];
        ps2->audoEntries[i].channels      = buf[10];
        ps2->audoEntries[i].bitsPerSample = buf[11];
        ps2->audoEntries[i].format        = buf[12];
        // buf[13..15] reserved
        ps2->audoEntries[i].sampleCount   = *(uint32_t*) &buf[16];
    }

    // Parse MUS string table + MUS entries
    ps2->musEntries = safeMalloc(ps2->musEntryCount * sizeof(Ps2MusEntry));

    // First pass: read the string table (u8 nameLength + name bytes per entry)
    repeat(ps2->musEntryCount, i) {
        uint8_t nameLen;
        fread(&nameLen, 1, 1, f);
        char* name = safeMalloc(nameLen + 1);
        fread(name, 1, nameLen, f);
        name[nameLen] = '\0';
        ps2->musEntries[i].name = name;
    }

    // Second pass: read the MUS entries (16 bytes each)
    repeat(ps2->musEntryCount, i) {
        uint8_t buf[16];
        fread(buf, 16, 1, f);
        ps2->musEntries[i].dataOffset  = *(uint32_t*) &buf[0];
        ps2->musEntries[i].dataSize    = *(uint32_t*) &buf[4];
        ps2->musEntries[i].sampleRate  = *(uint16_t*) &buf[8];
        ps2->musEntries[i].channels    = buf[10];
        ps2->musEntries[i].format      = buf[11];
        ps2->musEntries[i].sampleCount = *(uint32_t*) &buf[12];
    }

    if (ps2->musEntryCount > 0) {
        logInfo("PS2AudioSystem: Loaded %d MUS entries\n", ps2->musEntryCount);
    }

    fclose(f);
}

// ===[ SOUNDS.BIN File Handle ]===

static void openSoundsBin(Ps2AudioSystem* ps2) {
    // SOUNDS.BIN is always alongside the ELF on the boot device, not in the FileSystem mappings
    // We keep the file handle open and read on demand to avoid loading everything into EE RAM
    char* path = PS2Utils_createDevicePath("SOUNDS.BIN");

    ps2->soundsFile = fopen(path, "rb");
    if (ps2->soundsFile == nullptr) {
        logWarn("PS2AudioSystem: Could not open SOUNDS.BIN at %s\n", path);
        free(path);
        return;
    }

    logInfo("PS2AudioSystem: Opened SOUNDS.BIN for streaming (%s)\n", path);
    free(path);
}

// ===[ LRU Decoded PCM Cache (SFX) ]===

static DecodedPcmEntry* cacheGet(Ps2AudioSystem* ps2, int32_t audoIndex) {
    for (int i = 0; LRU_CACHE_SIZE > i; i++) {
        if (ps2->cacheEntries[i].audoIndex == audoIndex) {
            ps2->cacheEntries[i].lastAccessCounter = ++ps2->cacheAccessCounter;
            return &ps2->cacheEntries[i];
        }
    }
    return nullptr;
}

static bool cacheIsInUse(Ps2AudioSystem* ps2, int32_t audoIndex) {
    repeat(MAX_PS2_SOUND_INSTANCES, i) {
        if (ps2->instances[i].active && ps2->instances[i].audoIndex == audoIndex) {
            return true;
        }
    }
    return false;
}

static DecodedPcmEntry* cacheInsert(Ps2AudioSystem* ps2, int32_t audoIndex) {
    Ps2AudoEntry* audo = &ps2->audoEntries[audoIndex];

    // Compute decoded sample count: IMA ADPCM = 2 samples per byte
    uint32_t sampleCount = audo->dataSize * 2;
    uint32_t pcmBytes = sampleCount * sizeof(int16_t);

    // Find a free slot
    DecodedPcmEntry* slot = nullptr;
    for (int i = 0; LRU_CACHE_SIZE > i; i++) {
        if (0 > ps2->cacheEntries[i].audoIndex) {
            slot = &ps2->cacheEntries[i];
            break;
        }
    }

    // No free slot: evict LRU entry not in active use
    if (slot == nullptr) {
        uint32_t oldestAccess = UINT32_MAX;
        for (int i = 0; LRU_CACHE_SIZE > i; i++) {
            DecodedPcmEntry* entry = &ps2->cacheEntries[i];
            if (!cacheIsInUse(ps2, entry->audoIndex) && oldestAccess > entry->lastAccessCounter) {
                oldestAccess = entry->lastAccessCounter;
                slot = entry;
            }
        }

        if (slot == nullptr) {
            // logWarn("PS2AudioSystem: Cache full, all entries in use! Cannot decode audoIndex %" PRId32 "\n", audoIndex);
            return nullptr;
        }

        // Free the evicted entry's PCM data
        free(slot->pcmData);
    }

    // Read compressed ADPCM data from SOUNDS.BIN on demand
    uint8_t* adpcmBuf = safeMalloc(audo->dataSize);
    fseek(ps2->soundsFile, (long) audo->dataOffset, SEEK_SET);
    fread(adpcmBuf, 1, audo->dataSize, ps2->soundsFile);

    // Decode IMA ADPCM into new PCM buffer
    slot->pcmData = safeMalloc(pcmBytes);
    imaAdpcmDecode(adpcmBuf, audo->dataSize, slot->pcmData);
    free(adpcmBuf);

    slot->audoIndex = audoIndex;
    slot->pcmSampleCount = sampleCount;
    slot->pcmDataBytes = pcmBytes;
    slot->lastAccessCounter = ++ps2->cacheAccessCounter;

    return slot;
}

// ===[ Streaming Music ]===

// Fill one buffer of a music stream by reading ADPCM from SOUNDS.BIN and decoding
static void streamFillBuffer(Ps2AudioSystem* ps2, Ps2MusicStream* stream, int bufferIndex) {
    if (stream->fileOffset >= stream->fileEndOffset) {
        // No more data to read
        stream->bufferSampleCount[bufferIndex] = 0;
        return;
    }

    // How many ADPCM bytes remain for this track?
    uint32_t remaining = stream->fileEndOffset - stream->fileOffset;
    uint32_t toRead = STREAM_ADPCM_CHUNK_BYTES;
    if (toRead > remaining) toRead = remaining;

    // Read ADPCM chunk from disc
    uint8_t adpcmBuf[STREAM_ADPCM_CHUNK_BYTES];
    fseek(ps2->soundsFile, (long) stream->fileOffset, SEEK_SET);
    size_t bytesRead = fread(adpcmBuf, 1, toRead, ps2->soundsFile);
    stream->fileOffset += (uint32_t) bytesRead;

    // Decode into the target buffer, continuing decoder state
    uint32_t samples = imaAdpcmDecodeBlock(adpcmBuf, (uint32_t) bytesRead, stream->buffers[bufferIndex], &stream->decoderPredictor, &stream->decoderStepIndex);
    stream->bufferSampleCount[bufferIndex] = samples;

    if (stream->fileOffset >= stream->fileEndOffset) {
        stream->endOfTrack = true;
    }
}

// Reset a stream to the beginning of its track (for looping)
static void streamResetToStart(Ps2AudioSystem* ps2, Ps2MusicStream* stream) {
    stream->fileOffset = stream->fileStartOffset;
    stream->decoderPredictor = 0;
    stream->decoderStepIndex = 0;
    stream->endOfTrack = false;
    stream->readPosition = 0;
    stream->readPositionFrac = 0;

    // Fill both buffers from the start
    streamFillBuffer(ps2, stream, 0);
    streamFillBuffer(ps2, stream, 1);
    stream->activeBuffer = 0;
    stream->needsRefill = false;
}

// ===[ SFX Instance Helpers ]===

static Ps2SoundInstance* findFreeSlot(Ps2AudioSystem* ps2) {
    // First pass: find an inactive slot
    repeat(MAX_PS2_SOUND_INSTANCES, i) {
        if (!ps2->instances[i].active) {
            return &ps2->instances[i];
        }
    }

    // Second pass: evict the lowest-priority ended sound
    Ps2SoundInstance* best = nullptr;
    repeat(MAX_PS2_SOUND_INSTANCES, i) {
        Ps2SoundInstance* inst = &ps2->instances[i];
        if (inst->positionInt >= inst->totalSamples && !inst->loop) {
            if (best == nullptr || best->priority > inst->priority) {
                best = inst;
            }
        }
    }

    if (best != nullptr) {
        best->active = false;
    }

    return best;
}

static Ps2SoundInstance* findSfxInstanceById(Ps2AudioSystem* ps2, int32_t instanceId) {
    for (int32_t i = 0; i < MAX_PS2_SOUND_INSTANCES; i++) {
        Ps2SoundInstance* inst = &ps2->instances[i];
        if (inst->active && inst->instanceId == instanceId)
            return inst;
    }
    return nullptr;
}

// Find a music stream by instance ID
static Ps2MusicStream* findMusicStreamById(Ps2AudioSystem* ps2, int32_t instanceId) {
    repeat(MAX_MUSIC_STREAMS, i) {
        if (ps2->musicStreams[i].active && ps2->musicStreams[i].instanceId == instanceId) {
            return &ps2->musicStreams[i];
        }
    }
    return nullptr;
}

// Get the sample rate for a music stream (from AUDO or MUS entry)
static uint16_t getMusicStreamSampleRate(Ps2AudioSystem* ps2, Ps2MusicStream* stream) {
    if (stream->soundIndex >= PS2_AUDIO_STREAM_INDEX_BASE) {
        int32_t musIndex = stream->soundIndex - PS2_AUDIO_STREAM_INDEX_BASE;
        if (ps2->musEntryCount > musIndex) return ps2->musEntries[musIndex].sampleRate;
        return AUDSRV_OUTPUT_FREQ;
    }
    if ((uint16_t) stream->audoIndex < ps2->audoEntryCount) return ps2->audoEntries[stream->audoIndex].sampleRate;
    return AUDSRV_OUTPUT_FREQ;
}

// ===[ Software Mixer ]===

static float spatialGain(const AudioSystem* audio, bool spatial, float x, float y, float z, float ref, float max, float factor) {
    if (!spatial || factor <= 0) return 1.0f;
    float dx = x - audio->listenerX;
    float dy = y - audio->listenerY;
    float dz = z - audio->listenerZ;
    float distance = sqrtf(dx * dx + dy * dy + dz * dz);
    if (distance > max) distance = max;
    if (distance <= ref) return 1.0f;
    float denominator = ref + factor * (distance - ref);
    return denominator > 0 ? ref / denominator : 1.0f;
}

static void mixAudio(Ps2AudioSystem* ps2, int16_t* outBuf, int32_t samplePairs) {
    int32_t* accum = ps2->mixAccum;
    memset(accum, 0, samplePairs * sizeof(int32_t));

    // ===[ Mix SFX instances (from LRU cache) ]===
    repeat(MAX_PS2_SOUND_INSTANCES, i) {
        Ps2SoundInstance* inst = &ps2->instances[i];
        if (!inst->active || inst->paused) continue;

        DecodedPcmEntry* cache = cacheGet(ps2, inst->audoIndex);
        if (cache == nullptr) continue;

        if (inst->positionInt >= inst->totalSamples) {
            if (inst->loop) {
                inst->positionInt = 0;
                inst->positionFrac = 0;
            } else {
                inst->active = false;
                continue;
            }
        }

        // Hoist per-instance constants out of the per-sample loop
        const int16_t* pcm = cache->pcmData;
        uint32_t totalSamples = inst->totalSamples;
        bool loop = inst->loop;
        float gain = inst->currentGain * inst->sondVolume * ps2->masterGain *
            spatialGain(&ps2->base, inst->spatial, inst->spatialX, inst->spatialY, inst->spatialZ,
                        inst->falloffRef, inst->falloffMax, inst->falloffFactor) *
            AudioSystem_soundGroupGain(&ps2->base, inst->soundIndex);
        int32_t gainQ15 = (int32_t) (gain * 32768.0f);
        Ps2AudoEntry* audo = &ps2->audoEntries[inst->audoIndex];
        float stepRate = inst->pitch * inst->sondPitch * ((float) audo->sampleRate / (float) AUDSRV_OUTPUT_FREQ);
        uint32_t stepInt = (uint32_t) stepRate;
        uint32_t stepFrac = (uint32_t) ((stepRate - (float) stepInt) * 4294967296.0f);
        bool nativeRate = (stepInt == 1 && stepFrac == 0);

        uint32_t posInt = inst->positionInt;
        uint32_t posFrac = inst->positionFrac;
        bool ended = false;

        if (nativeRate) {
            // Fast path: no resampling, no fractional position (most SFX at 22050 Hz)
            for (int32_t s = 0; samplePairs > s; s++) {
                int32_t sample = pcm[posInt];
                accum[s] += (sample * gainQ15) >> 15;
                posInt++;

                if (posInt >= totalSamples) {
                    if (loop) {
                        posInt = 0;
                    } else {
                        ended = true;
                        break;
                    }
                }
            }
        } else {
            // Resampling path: linear interpolation with 32.32 fixed-point position
            for (int32_t s = 0; samplePairs > s; s++) {
                int32_t idx0 = (int32_t) posInt;
                int32_t idx1 = idx0 + 1;
                if ((uint32_t) idx1 >= totalSamples) idx1 = idx0;

                int32_t s0 = pcm[idx0];
                int32_t s1 = pcm[idx1];
                int32_t frac = (int32_t) (posFrac >> 16);
                int32_t sample = s0 + ((s1 - s0) * frac >> 16);

                accum[s] += (sample * gainQ15) >> 15;

                uint32_t oldFrac = posFrac;
                posFrac += stepFrac;
                if (oldFrac > posFrac) posInt++;
                posInt += stepInt;

                if (posInt >= totalSamples) {
                    if (loop) {
                        posInt = posInt % totalSamples;
                        posFrac = 0;
                    } else {
                        ended = true;
                        break;
                    }
                }
            }
        }

        inst->positionInt = posInt;
        inst->positionFrac = posFrac;
        if (ended) inst->active = false;
    }

    // ===[ Mix streaming music instances ]===
    repeat(MAX_MUSIC_STREAMS, i) {
        Ps2MusicStream* stream = &ps2->musicStreams[i];
        if (!stream->active || stream->paused) continue;

        // Hoist per-stream constants (pitch/sampleRate don't change mid-mix)
        float gain = stream->currentGain * stream->sondVolume * ps2->masterGain *
            spatialGain(&ps2->base, stream->spatial, stream->spatialX, stream->spatialY, stream->spatialZ,
                        stream->falloffRef, stream->falloffMax, stream->falloffFactor) *
            AudioSystem_soundGroupGain(&ps2->base, stream->soundIndex);
        int32_t gainQ15 = (int32_t) (gain * 32768.0f);
        uint16_t streamSampleRate = getMusicStreamSampleRate(ps2, stream);
        float stepRate = stream->pitch * stream->sondPitch * ((float) streamSampleRate / (float) AUDSRV_OUTPUT_FREQ);
        uint32_t stepInt = (uint32_t) stepRate;
        uint32_t stepFrac = (uint32_t) ((stepRate - (float) stepInt) * 4294967296.0f);
        bool nativeRate = (stepInt == 1 && stepFrac == 0);

        for (int32_t s = 0; samplePairs > s; s++) {
            uint32_t bufSamples = stream->bufferSampleCount[stream->activeBuffer];

            // Check if we've exhausted the active buffer
            if (stream->readPosition >= bufSamples) {
                if (stream->needsRefill && stream->endOfTrack) {
                    if (stream->loop) {
                        streamResetToStart(ps2, stream);
                        bufSamples = stream->bufferSampleCount[stream->activeBuffer];
                    } else {
                        stream->active = false;
                        break;
                    }
                } else {
                    // Swap to the back buffer (which should have been refilled)
                    stream->activeBuffer ^= 1;
                    stream->readPosition = 0;
                    stream->readPositionFrac = 0;
                    stream->needsRefill = true;
                    bufSamples = stream->bufferSampleCount[stream->activeBuffer];

                    if (bufSamples == 0) {
                        if (stream->loop) {
                            streamResetToStart(ps2, stream);
                            bufSamples = stream->bufferSampleCount[stream->activeBuffer];
                        } else {
                            stream->active = false;
                            break;
                        }
                    }
                }
            }

            int16_t* buf = stream->buffers[stream->activeBuffer];
            int32_t sample;

            if (nativeRate) {
                sample = buf[stream->readPosition];
            } else {
                int32_t idx0 = (int32_t) stream->readPosition;
                int32_t idx1 = idx0 + 1;
                if ((uint32_t) idx1 >= bufSamples) idx1 = idx0;

                int32_t s0 = buf[idx0];
                int32_t s1 = buf[idx1];
                int32_t frac = (int32_t) (stream->readPositionFrac >> 16);
                sample = s0 + ((s1 - s0) * frac >> 16);
            }

            accum[s] += (sample * gainQ15) >> 15;

            uint32_t oldFrac = stream->readPositionFrac;
            stream->readPositionFrac += stepFrac;
            if (oldFrac > stream->readPositionFrac) stream->readPosition++;
            stream->readPosition += stepInt;
        }
    }

    // ===[ Clamp mono accumulator and duplicate into interleaved stereo ]===
    for (int32_t s = 0; samplePairs > s; s++) {
        int32_t v = accum[s];
        if (v > 32767) v = 32767;
        if (-32768 > v) v = -32768;
        int16_t v16 = (int16_t) v;
        outBuf[s * 2]     = v16;
        outBuf[s * 2 + 1] = v16;
    }
}

// ===[ Vtable Implementations ]===

static void ps2Init(AudioSystem* audio, MAYBE_UNUSED DataWin* dataWin, MAYBE_UNUSED FileSystem* fileSystem) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    audio->dw = dataWin;

    // Parse sound bank index
    parseSoundBank(ps2);
    if (ps2->sondEntries == nullptr || ps2->audoEntries == nullptr) {
        logWarn("PS2AudioSystem: Failed to parse SOUNDBNK.BIN, audio disabled\n");
        return;
    }

    // Open SOUNDS.BIN for streaming (kept open for on-demand reads)
    openSoundsBin(ps2);
    if (ps2->soundsFile == nullptr) {
        logWarn("PS2AudioSystem: Failed to open SOUNDS.BIN, audio disabled\n");
        return;
    }

    // Initialize LRU cache (all slots empty)
    for (int i = 0; LRU_CACHE_SIZE > i; i++) {
        ps2->cacheEntries[i].audoIndex = -1;
        ps2->cacheEntries[i].pcmData = nullptr;
    }

    // Initialize sound instances
    memset(ps2->instances, 0, sizeof(ps2->instances));
    memset(ps2->musicStreams, 0, sizeof(ps2->musicStreams));
    ps2->nextInstanceCounter = 0;
    ps2->masterGain = 1.0f;

    // Initialize audsrv
    int ret = audsrv_init();
    if (ret != 0) {
        logWarn("PS2AudioSystem: audsrv_init failed (%d)\n", ret);
        return;
    }

    struct audsrv_fmt_t format;
    format.freq = AUDSRV_OUTPUT_FREQ;
    format.bits = 16;
    format.channels = 2;

    ret = audsrv_set_format(&format);
    if (ret != 0) {
        logWarn("PS2AudioSystem: audsrv_set_format failed (%d)\n", ret);
        audsrv_quit();
        return;
    }

    audsrv_set_volume(MAX_VOLUME);

    ps2->initialized = true;
    logInfo("PS2AudioSystem: Initialized (output: %d Hz, 16-bit, stereo)\n", AUDSRV_OUTPUT_FREQ);
}

static void ps2Destroy(AudioSystem* audio) {
    Fmod_audioDestroy(audio);
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    free(audio->groupGains);

    if (ps2->initialized) {
        audsrv_stop_audio();
        audsrv_quit();
    }

    // Close SOUNDS.BIN file handle
    if (ps2->soundsFile != nullptr) {
        fclose(ps2->soundsFile);
    }

    // Free all cached PCM data
    for (int i = 0; LRU_CACHE_SIZE > i; i++) {
        free(ps2->cacheEntries[i].pcmData);
    }

    // Free sound bank entries
    free(ps2->sondEntries);
    free(ps2->audoEntries);

    // Free MUS entry names
    repeat(ps2->musEntryCount, i) {
        free(ps2->musEntries[i].name);
    }
    free(ps2->musEntries);

    free(ps2);
}

static void ps2Update(AudioSystem* audio, float deltaTime) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    if (!ps2->initialized) return;

    // Cap deltaTime to prevent large fades on lag spikes
    if (deltaTime > 0.1f) deltaTime = 0.1f;
    AudioSystem_updateGroupGains(audio, deltaTime);

    // Update gain fading on SFX instances
    repeat(MAX_PS2_SOUND_INSTANCES, i) {
        Ps2SoundInstance* inst = &ps2->instances[i];
        if (!inst->active) continue;

        if (inst->fadeTimeRemaining > 0.0f) {
            inst->fadeTimeRemaining -= deltaTime;
            if (0.0f >= inst->fadeTimeRemaining) {
                inst->fadeTimeRemaining = 0.0f;
                inst->currentGain = inst->targetGain;
            } else {
                float t = 1.0f - (inst->fadeTimeRemaining / inst->fadeTotalTime);
                inst->currentGain = inst->startGain + (inst->targetGain - inst->startGain) * t;
            }
        }
    }

    // Update gain fading on music streams
    repeat(MAX_MUSIC_STREAMS, i) {
        Ps2MusicStream* stream = &ps2->musicStreams[i];
        if (!stream->active) continue;

        if (stream->fadeTimeRemaining > 0.0f) {
            stream->fadeTimeRemaining -= deltaTime;
            if (0.0f >= stream->fadeTimeRemaining) {
                stream->fadeTimeRemaining = 0.0f;
                stream->currentGain = stream->targetGain;
            } else {
                float t = 1.0f - (stream->fadeTimeRemaining / stream->fadeTotalTime);
                stream->currentGain = stream->startGain + (stream->targetGain - stream->startGain) * t;
            }
        }
    }

    // Refill music stream back buffers (do disc I/O here, outside the mixer loop)
    repeat(MAX_MUSIC_STREAMS, i) {
        Ps2MusicStream* stream = &ps2->musicStreams[i];
        if (!stream->active || !stream->needsRefill) continue;
        // logInfo("PS2AudioSystem: Filling music stream %d back buffers...\n", stream->soundIndex);

        int backBuffer = stream->activeBuffer ^ 1;
        streamFillBuffer(ps2, stream, backBuffer);
        stream->needsRefill = false;
    }

    // Fill audsrv ring buffer
    int32_t chunkBytes = MIX_BUFFER_SAMPLES * 2 * (int32_t) sizeof(int16_t);
    while (audsrv_available() >= chunkBytes) {
        // logInfo("PS2AudioSystem: Filling audsrv ring buffer... audsrv_available: %d, chunkBytes: %d\n", audsrv_available(), chunkBytes);
        mixAudio(ps2, ps2->mixBuffer, MIX_BUFFER_SAMPLES);
        audsrv_play_audio((char*) ps2->mixBuffer, chunkBytes);
    }

    // logInfo("PS2AudioSystem: Finished ticking the audio system\n");
}

static int32_t ps2PlaySound(AudioSystem* audio, int32_t soundIndex, int32_t priority, bool loop) {
    // logInfo("PS2AudioSystem: Attempting to play sound index %d with priority %d, should loop? %d\n", soundIndex, priority, loop);
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    if (!ps2->initialized) return -1;

    // Check if this is a MUS stream index (created by audio_create_stream)
    if (soundIndex >= PS2_AUDIO_STREAM_INDEX_BASE) {
        int32_t musIndex = soundIndex - PS2_AUDIO_STREAM_INDEX_BASE;
        if (musIndex >= ps2->musEntryCount) return -1;

        Ps2MusEntry* mus = &ps2->musEntries[musIndex];

        // Find a free music stream slot
        Ps2MusicStream* stream = nullptr;
        repeat(MAX_MUSIC_STREAMS, i) {
            if (!ps2->musicStreams[i].active) {
                stream = &ps2->musicStreams[i];
                break;
            }
        }

        if (stream == nullptr) {
            return -1;
        }

        int32_t instanceId = PS2_SOUND_INSTANCE_ID_BASE + ps2->nextInstanceCounter++;

        memset(stream, 0, sizeof(Ps2MusicStream));
        stream->active = true;
        stream->soundIndex = soundIndex;
        stream->audoIndex = -1;
        stream->instanceId = instanceId;
        stream->priority = priority;
        stream->loop = loop;
        stream->paused = false;
        stream->currentGain = 1.0f;
        stream->targetGain = 1.0f;
        stream->startGain = 1.0f;
        stream->sondVolume = 1.0f;
        stream->pitch = 1.0f;
        stream->sondPitch = 1.0f;

        stream->fileStartOffset = mus->dataOffset;
        stream->fileEndOffset = mus->dataOffset + mus->dataSize;
        stream->fileOffset = mus->dataOffset;
        stream->decoderPredictor = 0;
        stream->decoderStepIndex = 0;
        stream->endOfTrack = false;

        streamFillBuffer(ps2, stream, 0);
        streamFillBuffer(ps2, stream, 1);
        stream->activeBuffer = 0;
        stream->readPosition = 0;
        stream->needsRefill = false;

        // logInfo("PS2AudioSystem: Streaming MUS '%s', size=%" PRIu32 " bytes, instanceId=%" PRId32 "\n", mus->name, mus->dataSize, instanceId);

        return instanceId;
    }

    if (0 > soundIndex || (uint16_t) soundIndex >= ps2->sondEntryCount) {
        // logWarn("PS2AudioSystem: Invalid sound index %" PRId32 "\n", soundIndex);
        return -1;
    }

    Ps2SondEntry* sond = &ps2->sondEntries[soundIndex];

    // 0xFFFF = unmapped sound (no audio data)
    if (sond->audoIndex == 0xFFFF) {
        return -1;
    }

    if (sond->audoIndex >= ps2->audoEntryCount) {
        // logWarn("PS2AudioSystem: Invalid audo index %d for sound %" PRId32 "\n", sond->audoIndex, soundIndex);
        return -1;
    }

    // SOND volume and pitch are fixed-point * 256
    // A pitch of 0 means "default" (1.0) in GameMaker
    float sondVolume = (float) sond->volume / 256.0f;
    float sondPitch = (sond->pitch == 0) ? 1.0f : (float) sond->pitch / 256.0f;

    bool isEmbedded = (sond->flags & AUDIO_ENTRY_FLAG_IS_EMBEDDED) != 0;
    bool isCompressed = (sond->flags & AUDIO_ENTRY_FLAG_IS_COMPRESSED) != 0;

    // Some sounds are mis-flagged as embedded when they are actually long tracks (example: "spamton_neo_mix_ex_wip" in DELTARUNE Chapter 2)
    // Decoding them into the LRU cache would blow EE RAM, so force them through the streaming path when the decoded PCM would exceed the cache budget.
    Ps2AudoEntry* audoForSize = &ps2->audoEntries[sond->audoIndex];
    uint32_t decodedPcmBytes = audoForSize->dataSize * 2 * (uint32_t) sizeof(int16_t);
    if ((isEmbedded || isCompressed) && decodedPcmBytes > PS2_SFX_CACHE_MAX_BYTES) {
        logWarn("PS2AudioSystem: Sound %" PRId32 " (audo %d) would need %" PRIu32 " bytes of PCM in the cache! isEmbedded? %s; isCompressed? %s; Streaming instead...\n", soundIndex, sond->audoIndex, decodedPcmBytes, isEmbedded ? "true" : "false", isCompressed ? "true" : "false");
        isEmbedded = false;
        isCompressed = false;
    }

    if (!isEmbedded && !isCompressed) {
        // ===[ Streaming music path ]===
        // Find a free music stream slot
        Ps2MusicStream* stream = nullptr;
        repeat(MAX_MUSIC_STREAMS, i) {
            if (!ps2->musicStreams[i].active) {
                stream = &ps2->musicStreams[i];
                break;
            }
        }

        if (stream == nullptr) {
            // logWarn("PS2AudioSystem: No free music stream slots for sound %" PRId32 "\n", soundIndex);
            return -1;
        }

        Ps2AudoEntry* audo = &ps2->audoEntries[sond->audoIndex];

        // Unique IDs prevent a stopped emitter voice from referring to a reused stream slot.
        int32_t instanceId = PS2_SOUND_INSTANCE_ID_BASE + ps2->nextInstanceCounter++;

        memset(stream, 0, sizeof(Ps2MusicStream));
        stream->active = true;
        stream->soundIndex = soundIndex;
        stream->audoIndex = sond->audoIndex;
        stream->instanceId = instanceId;
        stream->priority = priority;
        stream->loop = loop;
        stream->paused = false;
        stream->currentGain = sondVolume;
        stream->targetGain = sondVolume;
        stream->startGain = sondVolume;
        stream->sondVolume = sondVolume;
        stream->pitch = 1.0f;
        stream->sondPitch = sondPitch;

        // Set up file streaming state
        stream->fileStartOffset = audo->dataOffset;
        stream->fileEndOffset = audo->dataOffset + audo->dataSize;
        stream->fileOffset = audo->dataOffset;
        stream->decoderPredictor = 0;
        stream->decoderStepIndex = 0;
        stream->endOfTrack = false;

        // Fill both buffers initially
        streamFillBuffer(ps2, stream, 0);
        streamFillBuffer(ps2, stream, 1);
        stream->activeBuffer = 0;
        stream->readPosition = 0;
        stream->needsRefill = false;

        // logInfo("PS2AudioSystem: Streaming music soundIndex=%" PRId32 " audoIndex=%d, size=%" PRIu32 " bytes, instanceId=%" PRId32 "\n", soundIndex, sond->audoIndex, audo->dataSize, instanceId);

        return instanceId;
    }

    // ===[ Cached SFX path ]===
    // Ensure decoded PCM is in cache
    DecodedPcmEntry* cached = cacheGet(ps2, sond->audoIndex);
    if (cached == nullptr) {
        cached = cacheInsert(ps2, sond->audoIndex);
        if (cached == nullptr) {
            // logWarn("PS2AudioSystem: Failed to cache decoded audio for sound %" PRId32 "\n", soundIndex);
            return -1;
        }
    }

    // Find a free SFX instance slot
    Ps2SoundInstance* slot = findFreeSlot(ps2);
    if (slot == nullptr) {
        // logWarn("PS2AudioSystem: No free sound slots for sound %" PRId32 "\n", soundIndex);
        return -1;
    }

    slot->spatial = false;
    slot->active = true;
    slot->soundIndex = soundIndex;
    slot->audoIndex = sond->audoIndex;
    slot->instanceId = PS2_SOUND_INSTANCE_ID_BASE + ps2->nextInstanceCounter++;
    slot->priority = priority;
    slot->loop = loop;
    slot->paused = false;
    slot->positionInt = 0;
    slot->positionFrac = 0;
    slot->totalSamples = cached->pcmSampleCount;
    slot->pitch = 1.0f;
    slot->sondPitch = sondPitch;
    slot->currentGain = sondVolume;
    slot->targetGain = sondVolume;
    slot->startGain = sondVolume;
    slot->fadeTimeRemaining = 0.0f;
    slot->fadeTotalTime = 0.0f;
    slot->sondVolume = sondVolume;

    ps2->nextInstanceCounter++;

    return slot->instanceId;
}

// ===[ Helper: Apply action to SFX instance, music stream, or all matching by soundIndex ]===
// These helpers handle the dual SFX/music lookup needed by stop/pause/resume/gain/pitch/etc.

// Find either a SFX instance or music stream by instanceId or soundIndex
// For instanceId lookups (>= PS2_SOUND_INSTANCE_ID_BASE), returns at most one match.
// For soundIndex lookups, iterates all matches via callback.

typedef void (*InstanceAction)(Ps2SoundInstance* sfx, Ps2MusicStream* music, void* userData);

static void forEachInstance(Ps2AudioSystem* ps2, int32_t soundOrInstance, InstanceAction action, void* userData) {
    if (soundOrInstance >= PS2_AUDIO_STREAM_INDEX_BASE) {
        // MUS stream resource index: match by soundIndex on music streams
        repeat(MAX_MUSIC_STREAMS, i) {
            if (ps2->musicStreams[i].active && ps2->musicStreams[i].soundIndex == soundOrInstance) {
                action(nullptr, &ps2->musicStreams[i], userData);
            }
        }
    } else if (soundOrInstance >= PS2_SOUND_INSTANCE_ID_BASE) {
        // Lookup by instance ID
        Ps2SoundInstance* sfx = findSfxInstanceById(ps2, soundOrInstance);
        if (sfx != nullptr) {
            action(sfx, nullptr, userData);
            return;
        }
        Ps2MusicStream* music = findMusicStreamById(ps2, soundOrInstance);
        if (music != nullptr) {
            action(nullptr, music, userData);
            return;
        }
    } else {
        // Lookup by sound index -- apply to all matching
        repeat(MAX_PS2_SOUND_INSTANCES, i) {
            if (ps2->instances[i].active && ps2->instances[i].soundIndex == soundOrInstance) {
                action(&ps2->instances[i], nullptr, userData);
            }
        }
        repeat(MAX_MUSIC_STREAMS, i) {
            if (ps2->musicStreams[i].active && ps2->musicStreams[i].soundIndex == soundOrInstance) {
                action(nullptr, &ps2->musicStreams[i], userData);
            }
        }
    }
}

static void actionStop(Ps2SoundInstance* sfx, Ps2MusicStream* music, MAYBE_UNUSED void* userData) {
    if (sfx != nullptr) sfx->active = false;
    if (music != nullptr) music->active = false;
}

static void actionPause(Ps2SoundInstance* sfx, Ps2MusicStream* music, MAYBE_UNUSED void* userData) {
    if (sfx != nullptr) sfx->paused = true;
    if (music != nullptr) music->paused = true;
}

static void actionResume(Ps2SoundInstance* sfx, Ps2MusicStream* music, MAYBE_UNUSED void* userData) {
    if (sfx != nullptr) sfx->paused = false;
    if (music != nullptr) music->paused = false;
}

typedef struct {
    float gain;
    uint32_t timeMs;
} GainParams;

static void actionSetGain(Ps2SoundInstance* sfx, Ps2MusicStream* music, void* userData) {
    GainParams* params = (GainParams*) userData;
    float gain = params->gain;
    uint32_t timeMs = params->timeMs;

    if (sfx != nullptr) {
        if (timeMs == 0) {
            sfx->currentGain = gain;
            sfx->targetGain = gain;
            sfx->fadeTimeRemaining = 0.0f;
        } else {
            sfx->startGain = sfx->currentGain;
            sfx->targetGain = gain;
            sfx->fadeTotalTime = (float) timeMs / 1000.0f;
            sfx->fadeTimeRemaining = sfx->fadeTotalTime;
        }
    }
    if (music != nullptr) {
        if (timeMs == 0) {
            music->currentGain = gain;
            music->targetGain = gain;
            music->fadeTimeRemaining = 0.0f;
        } else {
            music->startGain = music->currentGain;
            music->targetGain = gain;
            music->fadeTotalTime = (float) timeMs / 1000.0f;
            music->fadeTimeRemaining = music->fadeTotalTime;
        }
    }
}

static void actionSetPitch(Ps2SoundInstance* sfx, Ps2MusicStream* music, void* userData) {
    float pitch = *(float*) userData;
    if (sfx != nullptr) sfx->pitch = pitch;
    if (music != nullptr) music->pitch = pitch;
}

// ===[ Vtable: Stop/Pause/Resume/Gain/Pitch ]===

static void ps2StopSound(AudioSystem* audio, int32_t soundOrInstance) {
    // logInfo("PS2AudioSystem: Stopping sound %d\n", soundOrInstance);
    forEachInstance((Ps2AudioSystem*) audio, soundOrInstance, actionStop, nullptr);
}

static void ps2SetSoundSpatial(AudioSystem* audio, int32_t instanceId, float x, float y, float z, float vx, float vy, float vz, float ref, float max, float factor) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*)audio;
    Ps2SoundInstance* sfx = findSfxInstanceById(ps2, instanceId);
    Ps2MusicStream* music = findMusicStreamById(ps2, instanceId);
    if (sfx != nullptr) {
        sfx->spatial = true;
        sfx->spatialX = x; sfx->spatialY = y; sfx->spatialZ = z;
        sfx->velocityX = vx; sfx->velocityY = vy; sfx->velocityZ = vz;
        sfx->falloffRef = ref > 0 ? ref : 0.0001f;
        sfx->falloffMax = max > 0 ? max : 0.0001f;
        sfx->falloffFactor = factor;
    }
    if (music != nullptr) {
        music->spatial = true;
        music->spatialX = x; music->spatialY = y; music->spatialZ = z;
        music->velocityX = vx; sfx->velocityY = vy; sfx->velocityZ = vz;
        music->falloffRef = ref > 0 ? ref : 0.0001f;
        music->falloffMax = max > 0 ? max : 0.0001f;
        music->falloffFactor = factor;
    }
}

static void ps2SetListenerPosition(MAYBE_UNUSED AudioSystem* audio, MAYBE_UNUSED float x, MAYBE_UNUSED float y, MAYBE_UNUSED float z) {
    // The mixer reads the listener coordinates stored in AudioSystem.
}

static void ps2StopAll(AudioSystem* audio) {
    // logInfo("PS2AudioSystem: Stopping all audios!\n");
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    repeat(MAX_PS2_SOUND_INSTANCES, i) {
        ps2->instances[i].active = false;
    }
    repeat(MAX_MUSIC_STREAMS, i) {
        ps2->musicStreams[i].active = false;
    }
}

static bool ps2IsPlaying(AudioSystem* audio, int32_t soundOrInstance) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;

    if (soundOrInstance >= PS2_AUDIO_STREAM_INDEX_BASE) {
        // MUS stream resource index: match by soundIndex on music streams
        repeat(MAX_MUSIC_STREAMS, i) {
            Ps2MusicStream* stream = &ps2->musicStreams[i];
            if (stream->active && stream->soundIndex == soundOrInstance && !stream->paused) return true;
        }
        return false;
    } else if (soundOrInstance >= PS2_SOUND_INSTANCE_ID_BASE) {
        Ps2SoundInstance* sfx = findSfxInstanceById(ps2, soundOrInstance);
        if (sfx != nullptr) return !sfx->paused;
        Ps2MusicStream* music = findMusicStreamById(ps2, soundOrInstance);
        if (music != nullptr) return !music->paused;
        return false;
    } else {
        repeat(MAX_PS2_SOUND_INSTANCES, i) {
            Ps2SoundInstance* inst = &ps2->instances[i];
            if (inst->active && inst->soundIndex == soundOrInstance && !inst->paused) return true;
        }
        repeat(MAX_MUSIC_STREAMS, i) {
            Ps2MusicStream* stream = &ps2->musicStreams[i];
            if (stream->active && stream->soundIndex == soundOrInstance && !stream->paused) return true;
        }
        return false;
    }
}

static void ps2PauseSound(AudioSystem* audio, int32_t soundOrInstance) {
    // logInfo("PS2AudioSystem: Pausing sound %d\n", soundOrInstance);
    forEachInstance((Ps2AudioSystem*) audio, soundOrInstance, actionPause, nullptr);
}

static void ps2ResumeSound(AudioSystem* audio, int32_t soundOrInstance) {
    // logInfo("PS2AudioSystem: Resuming sound %d\n", soundOrInstance);
    forEachInstance((Ps2AudioSystem*) audio, soundOrInstance, actionResume, nullptr);
}

static void ps2PauseAll(AudioSystem* audio) {
    // logInfo("PS2AudioSystem: Pausing all sounds!\n");
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    repeat(MAX_PS2_SOUND_INSTANCES, i) {
        if (ps2->instances[i].active) ps2->instances[i].paused = true;
    }
    repeat(MAX_MUSIC_STREAMS, i) {
        if (ps2->musicStreams[i].active) ps2->musicStreams[i].paused = true;
    }
}

static void ps2ResumeAll(AudioSystem* audio) {
    // logInfo("PS2AudioSystem: Resuming all sounds!\n");
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    repeat(MAX_PS2_SOUND_INSTANCES, i) {
        if (ps2->instances[i].active) ps2->instances[i].paused = false;
    }
    repeat(MAX_MUSIC_STREAMS, i) {
        if (ps2->musicStreams[i].active) ps2->musicStreams[i].paused = false;
    }
}

static void ps2SetSoundGain(AudioSystem* audio, int32_t soundOrInstance, float gain, uint32_t timeMs) {
    GainParams params = { .gain = gain, .timeMs = timeMs };
    forEachInstance((Ps2AudioSystem*) audio, soundOrInstance, actionSetGain, &params);
}

static void ps2SetGroupGain(AudioSystem* audio, int32_t groupIndex, float gain, uint32_t timeMs) {
    AudioSystem_setGroupGain(audio, groupIndex, gain, timeMs);
}

static float ps2GetSoundGain(AudioSystem* audio, int32_t soundOrInstance) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    if (soundOrInstance >= PS2_AUDIO_STREAM_INDEX_BASE) {
        repeat(MAX_MUSIC_STREAMS, i) {
            if (ps2->musicStreams[i].active && ps2->musicStreams[i].soundIndex == soundOrInstance) return ps2->musicStreams[i].currentGain;
        }
    } else if (soundOrInstance >= PS2_SOUND_INSTANCE_ID_BASE) {
        Ps2SoundInstance* sfx = findSfxInstanceById(ps2, soundOrInstance);
        if (sfx != nullptr) return sfx->currentGain;
        Ps2MusicStream* music = findMusicStreamById(ps2, soundOrInstance);
        if (music != nullptr) return music->currentGain;
    } else {
        repeat(MAX_PS2_SOUND_INSTANCES, i) {
            if (ps2->instances[i].active && ps2->instances[i].soundIndex == soundOrInstance) return ps2->instances[i].currentGain;
        }
        repeat(MAX_MUSIC_STREAMS, i) {
            if (ps2->musicStreams[i].active && ps2->musicStreams[i].soundIndex == soundOrInstance) return ps2->musicStreams[i].currentGain;
        }
    }
    return 0.0f;
}

static void ps2SetSoundPitch(AudioSystem* audio, int32_t soundOrInstance, float pitch) {
    // logInfo("PS2AudioSystem: Setting pitch of sound %d to %f\n", soundOrInstance, pitch);
    forEachInstance((Ps2AudioSystem*) audio, soundOrInstance, actionSetPitch, &pitch);
}

static float ps2GetSoundPitch(AudioSystem* audio, int32_t soundOrInstance) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    if (soundOrInstance >= PS2_AUDIO_STREAM_INDEX_BASE) {
        repeat(MAX_MUSIC_STREAMS, i) {
            if (ps2->musicStreams[i].active && ps2->musicStreams[i].soundIndex == soundOrInstance) return ps2->musicStreams[i].pitch;
        }
    } else if (soundOrInstance >= PS2_SOUND_INSTANCE_ID_BASE) {
        Ps2SoundInstance* sfx = findSfxInstanceById(ps2, soundOrInstance);
        if (sfx != nullptr) return sfx->pitch;
        Ps2MusicStream* music = findMusicStreamById(ps2, soundOrInstance);
        if (music != nullptr) return music->pitch;
    } else {
        repeat(MAX_PS2_SOUND_INSTANCES, i) {
            if (ps2->instances[i].active && ps2->instances[i].soundIndex == soundOrInstance) return ps2->instances[i].pitch;
        }
        repeat(MAX_MUSIC_STREAMS, i) {
            if (ps2->musicStreams[i].active && ps2->musicStreams[i].soundIndex == soundOrInstance) return ps2->musicStreams[i].pitch;
        }
    }
    return 1.0f;
}

static float ps2GetTrackPosition(AudioSystem* audio, int32_t soundOrInstance) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;

    if (soundOrInstance >= PS2_AUDIO_STREAM_INDEX_BASE) {
        // MUS stream resource index
        repeat(MAX_MUSIC_STREAMS, i) {
            Ps2MusicStream* stream = &ps2->musicStreams[i];
            if (stream->active && stream->soundIndex == soundOrInstance) {
                uint32_t bytesConsumed = stream->fileOffset - stream->fileStartOffset;
                uint32_t samplesConsumed = bytesConsumed * 2;
                return (float) samplesConsumed / (float) getMusicStreamSampleRate(ps2, stream);
            }
        }
    } else if (soundOrInstance >= PS2_SOUND_INSTANCE_ID_BASE) {
        Ps2SoundInstance* sfx = findSfxInstanceById(ps2, soundOrInstance);
        if (sfx != nullptr && sfx->audoIndex < ps2->audoEntryCount) {
            return (float) sfx->positionInt / (float) ps2->audoEntries[sfx->audoIndex].sampleRate;
        }
        Ps2MusicStream* music = findMusicStreamById(ps2, soundOrInstance);
        if (music != nullptr) {
            uint32_t bytesConsumed = music->fileOffset - music->fileStartOffset;
            uint32_t samplesConsumed = bytesConsumed * 2;
            return (float) samplesConsumed / (float) getMusicStreamSampleRate(ps2, music);
        }
    } else {
        repeat(MAX_PS2_SOUND_INSTANCES, i) {
            Ps2SoundInstance* inst = &ps2->instances[i];
            if (inst->active && inst->soundIndex == soundOrInstance && inst->audoIndex < ps2->audoEntryCount) {
                return (float) inst->positionInt / (float) ps2->audoEntries[inst->audoIndex].sampleRate;
            }
        }
        repeat(MAX_MUSIC_STREAMS, i) {
            Ps2MusicStream* stream = &ps2->musicStreams[i];
            if (stream->active && stream->soundIndex == soundOrInstance) {
                uint32_t bytesConsumed = stream->fileOffset - stream->fileStartOffset;
                uint32_t samplesConsumed = bytesConsumed * 2;
                return (float) samplesConsumed / (float) getMusicStreamSampleRate(ps2, stream);
            }
        }
    }
    return 0.0f;
}

// Seek a music stream to a position in seconds
static void seekMusicStream(Ps2AudioSystem* ps2, Ps2MusicStream* music, float positionSeconds) {
    float sampleRate = (float) getMusicStreamSampleRate(ps2, music);
    uint32_t targetSample = (uint32_t) (positionSeconds * sampleRate);
    // Convert sample position to ADPCM byte offset (2 samples per byte)
    uint32_t byteOffset = targetSample / 2;
    uint32_t maxBytes = music->fileEndOffset - music->fileStartOffset;
    if (byteOffset > maxBytes) byteOffset = maxBytes;

    // Reset decoder state and seek
    music->fileOffset = music->fileStartOffset + byteOffset;
    music->decoderPredictor = 0;
    music->decoderStepIndex = 0;
    music->endOfTrack = false;
    music->readPosition = 0;

    // Re-fill both buffers from the new position
    streamFillBuffer(ps2, music, 0);
    streamFillBuffer(ps2, music, 1);
    music->activeBuffer = 0;
    music->needsRefill = false;
}

static void ps2SetTrackPosition(AudioSystem* audio, int32_t soundOrInstance, float positionSeconds) {
    // logInfo("PS2AudioSystem: Setting track position of sound %d to %f\n", soundOrInstance, positionSeconds);
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;

    if (soundOrInstance >= PS2_AUDIO_STREAM_INDEX_BASE) {
        // MUS stream resource index
        repeat(MAX_MUSIC_STREAMS, i) {
            Ps2MusicStream* stream = &ps2->musicStreams[i];
            if (stream->active && stream->soundIndex == soundOrInstance) {
                seekMusicStream(ps2, stream, positionSeconds);
                return;
            }
        }
    } else if (soundOrInstance >= PS2_SOUND_INSTANCE_ID_BASE) {
        // SFX track position
        Ps2SoundInstance* sfx = findSfxInstanceById(ps2, soundOrInstance);
        if (sfx != nullptr && sfx->audoIndex < ps2->audoEntryCount) {
            float sampleRate = (float) ps2->audoEntries[sfx->audoIndex].sampleRate;
            sfx->positionInt = (uint32_t) (positionSeconds * sampleRate);
            sfx->positionFrac = 0;
            if (sfx->positionInt >= sfx->totalSamples) {
                sfx->positionInt = sfx->totalSamples > 0 ? sfx->totalSamples - 1 : 0;
            }
            return;
        }
        // Music stream seek: reset decoder and re-seek
        Ps2MusicStream* music = findMusicStreamById(ps2, soundOrInstance);
        if (music != nullptr) {
            seekMusicStream(ps2, music, positionSeconds);
        }
    } else {
        // By sound index (apply to first match)
        repeat(MAX_PS2_SOUND_INSTANCES, i) {
            Ps2SoundInstance* inst = &ps2->instances[i];
            if (inst->active && inst->soundIndex == soundOrInstance && inst->audoIndex < ps2->audoEntryCount) {
                float sampleRate = (float) ps2->audoEntries[inst->audoIndex].sampleRate;
                inst->positionInt = (uint32_t) (positionSeconds * sampleRate);
                inst->positionFrac = 0;
                if (inst->positionInt >= inst->totalSamples) {
                    inst->positionInt = inst->totalSamples > 0 ? inst->totalSamples - 1 : 0;
                }
                return;
            }
        }
    }
}

// Total length of a sound in seconds. Looks up the AUDO or MUS entry's decoded sampleCount and divides by sampleRate.
static float ps2GetSoundLength(AudioSystem* audio, int32_t soundOrInstance) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;

    int32_t audoIndex = -1;
    int32_t musIndex = -1;

    if (soundOrInstance >= PS2_AUDIO_STREAM_INDEX_BASE) {
        musIndex = soundOrInstance - PS2_AUDIO_STREAM_INDEX_BASE;
    } else if (soundOrInstance >= PS2_SOUND_INSTANCE_ID_BASE) {
        Ps2SoundInstance* sfx = findSfxInstanceById(ps2, soundOrInstance);
        if (sfx != nullptr) {
            audoIndex = sfx->audoIndex;
        } else {
            Ps2MusicStream* music = findMusicStreamById(ps2, soundOrInstance);
            if (music != nullptr && music->soundIndex >= PS2_AUDIO_STREAM_INDEX_BASE) {
                musIndex = music->soundIndex - PS2_AUDIO_STREAM_INDEX_BASE;
            }
        }
    } else {
        // SOND resource index — map to AUDO via the SOND entry
        if (ps2->sondEntryCount > (uint32_t) soundOrInstance) {
            uint16_t mapped = ps2->sondEntries[soundOrInstance].audoIndex;
            if (mapped != 0xFFFF) audoIndex = mapped;
        }
    }

    if (ps2->audoEntryCount > (uint32_t) audoIndex) {
        if (audoIndex >= 0) {
            Ps2AudoEntry* audo = &ps2->audoEntries[audoIndex];
            if (audo->sampleRate == 0 || audo->sampleCount == 0) return 0.0f;
            return (float) audo->sampleCount / (float) audo->sampleRate;
        }
        if (musIndex >= 0) {
            Ps2MusEntry* mus = &ps2->musEntries[musIndex];
            if (mus->sampleRate == 0 || mus->sampleCount == 0) return 0.0f;
            return (float) mus->sampleCount / (float) mus->sampleRate;
        }
    }
    return 0.0f;
}

static void ps2SetMasterGain(AudioSystem* audio, float gain) {
    // logInfo("PS2AudioSystem: Setting master gain to %f\n", gain);
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    ps2->masterGain = gain;
}

static void ps2SetMasterGainForListener(AudioSystem* audio, float gain, int32_t id) {
    if (id != 0) return;
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    ps2->masterGain = gain;
}

static void ps2SetChannelCount(MAYBE_UNUSED AudioSystem* audio, MAYBE_UNUSED int32_t count) {
    // No-op: software mixer handles all channels internally
}

static void ps2GroupLoad(MAYBE_UNUSED AudioSystem* audio, MAYBE_UNUSED int32_t groupIndex) {
    // No-op: all audio is available from SOUNDS.BIN
}

static bool ps2GroupIsLoaded(MAYBE_UNUSED AudioSystem* audio, MAYBE_UNUSED int32_t groupIndex) {
    return true;
}

static int32_t ps2CreateStream(AudioSystem* audio, const char* filename) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;
    if (!ps2->initialized) return -1;

    // Look up the filename in the MUS string table
    for (int i = 0; ps2->musEntryCount > i; i++) {
        if (strcmp(ps2->musEntries[i].name, filename) == 0) {
            int32_t streamIndex = PS2_AUDIO_STREAM_INDEX_BASE + i;
            logInfo("PS2AudioSystem: Created stream %" PRId32 " for '%s'\n", streamIndex, filename);
            return streamIndex;
        }
    }

    logWarn("PS2AudioSystem: audio_create_stream: '%s' not found in MUS entries\n", filename);
    return -1;
}

static bool ps2DestroyStream(AudioSystem* audio, int32_t streamIndex) {
    Ps2AudioSystem* ps2 = (Ps2AudioSystem*) audio;

    // Stop all music streams that were playing this stream
    repeat(MAX_MUSIC_STREAMS, i) {
        if (ps2->musicStreams[i].active && ps2->musicStreams[i].soundIndex == streamIndex) {
            ps2->musicStreams[i].active = false;
        }
    }

    return true;
}

// ===[ Vtable ]===

static AudioSystemVtable ps2AudioSystemVtable;

// ===[ Lifecycle ]===

Ps2AudioSystem* Ps2AudioSystem_create(void) {
    Ps2AudioSystem* ps2 = safeCalloc(1, sizeof(Ps2AudioSystem));
    ps2AudioSystemVtable.init = ps2Init;
    ps2AudioSystemVtable.destroy = ps2Destroy;
    ps2AudioSystemVtable.update = ps2Update;
    ps2AudioSystemVtable.playSound = ps2PlaySound;
    ps2AudioSystemVtable.setSoundSpatial = ps2SetSoundSpatial;
    ps2AudioSystemVtable.setListenerPosition = ps2SetListenerPosition;
    ps2AudioSystemVtable.stopSound = ps2StopSound;
    ps2AudioSystemVtable.stopAll = ps2StopAll;
    ps2AudioSystemVtable.isPlaying = ps2IsPlaying;
    ps2AudioSystemVtable.pauseSound = ps2PauseSound;
    ps2AudioSystemVtable.resumeSound = ps2ResumeSound;
    ps2AudioSystemVtable.pauseAll = ps2PauseAll;
    ps2AudioSystemVtable.resumeAll = ps2ResumeAll;
    ps2AudioSystemVtable.suspend = ps2PauseAll;
    ps2AudioSystemVtable.resume = ps2ResumeAll;
    ps2AudioSystemVtable.setSoundGain = ps2SetSoundGain;
    ps2AudioSystemVtable.getSoundGain = ps2GetSoundGain;
    ps2AudioSystemVtable.setSoundPitch = ps2SetSoundPitch;
    ps2AudioSystemVtable.getSoundPitch = ps2GetSoundPitch;
    ps2AudioSystemVtable.getTrackPosition = ps2GetTrackPosition;
    ps2AudioSystemVtable.setTrackPosition = ps2SetTrackPosition;
    ps2AudioSystemVtable.getSoundLength = ps2GetSoundLength;
    ps2AudioSystemVtable.setMasterGain = ps2SetMasterGain;
    ps2AudioSystemVtable.setMasterGainForListener = ps2SetMasterGainForListener;
    ps2AudioSystemVtable.setChannelCount = ps2SetChannelCount;
    ps2AudioSystemVtable.setGroupGain = ps2SetGroupGain;
    ps2AudioSystemVtable.groupLoad = ps2GroupLoad;
    ps2AudioSystemVtable.groupIsLoaded = ps2GroupIsLoaded;
    ps2AudioSystemVtable.createStream = ps2CreateStream;
    ps2AudioSystemVtable.destroyStream = ps2DestroyStream;
    ps2->base.vtable = &ps2AudioSystemVtable;
    ps2->masterGain = 1.0f;
    return ps2;
}
