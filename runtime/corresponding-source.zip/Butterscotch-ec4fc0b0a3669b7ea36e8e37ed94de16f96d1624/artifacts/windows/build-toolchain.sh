#!/bin/sh
# shellcheck disable=2086
set -e

[ "${0%/*}" = "$0" ] && scriptroot="." || scriptroot="${0%/*}"
cd "$scriptroot"

arch="${ARCH:-x86_64}"
target="$arch-w64-mingw32"

platformdir=$PWD

workdir="$PWD/build"
mkdir -p "$workdir"
cd "$workdir"

if command -v nproc >/dev/null; then
    ncpus="$(nproc)"
else
    ncpus="$(sysctl -n hw.ncpu)"
fi

if command -v gmake > /dev/null; then
    _MAKE="gmake"
elif command -v make > /dev/null; then
    _make_version="$(command make --version 2>/dev/null)"
    case "$_make_version" in
        (*GNU*) _MAKE="make" ;;
        (*)
            printf 'Missing dependency: GNU make\n'
            exit 1
        ;;
    esac
else
    printf 'Missing dependency: GNU make\n'
    exit 1
fi

make() {
    command "$_MAKE" "$@"
}

export PATH="$PWD/toolchain-$arch/bin:$PATH"

# toolchainver should be increased if we ever make a change to the toolchain,
# for example using a newer GCC version, and we need to invalidate the cache.
toolchainver=5
if [ "$(cat "toolchain-$arch/toolchainver" 2>/dev/null)" = "$toolchainver" ]; then
    printf 'Toolchain already built! :)\n'
    exit 0
fi

# adapted from https://github.com/DiscordMessenger/dm/blob/master/doc/pentium-toolchain/README.md

case $arch in
    (i?86)
        winnt=0x0400 # Windows NT 4.0 (We actually support lower, but this is the lowest this value is supposed to be)
        crt=crtdll
    ;;
    (x86_64)
        winnt=0x0502 # Windows XP x64 edition / Server 2003
        crt=msvcrt
    ;;
    (arm64|aarch64)
        printf 'aarch64 builds are currently unsupported.\n'
        exit 1
        winnt=0x0A00 # Windows 10
        crt=ucrt
    ;;
    (*)
        printf 'Unknown architecture!\n'
        exit 1
    ;;
esac

rm -rf "toolchain-$arch"
printf '\nBuilding %s toolchain...\n\n' "$arch"

binutils_version='2.47'
rm -rf binutils-*
wget -O- "https://ftp.gnu.org/gnu/binutils/binutils-$binutils_version.tar.xz" | tar -xJ

cd "binutils-$binutils_version"
./configure \
    --prefix="$workdir/toolchain-$arch" \
    --target="$target" \
    --disable-multilib
make -j"$ncpus"
make -j"$ncpus" install-strip
cd ..
rm -rf "binutils-$binutils_version" &

mingw_version='14.0.0'
rm -rf mingw-w64-*
wget -O- "https://sourceforge.net/projects/mingw-w64/files/mingw-w64/mingw-w64-release/mingw-w64-v$mingw_version.tar.bz2/download" | tar -xj

cd "mingw-w64-v$mingw_version/mingw-w64-headers"
./configure \
    --host="$target" \
    --prefix="$workdir/toolchain-$arch/$target" \
    --with-default-win32-winnt="$winnt" \
    --with-default-msvcrt="$crt"
make -j"$ncpus" install
cd ../..

gcc_version='16.2.0'
rm -rf gcc-*
wget -O- "https://ftp.gnu.org/gnu/gcc/gcc-$gcc_version/gcc-$gcc_version.tar.xz" | tar -xJ

cd "gcc-$gcc_version"
patch -fNp1 < "$platformdir/gcc.diff"
mkdir build
cd build
set --
[ -n "$GMP" ] && set -- --with-gmp="$GMP"
[ -n "$MPFR" ] && set -- "$@" --with-mpfr="$MPFR"
[ -n "$MPC" ] && set -- "$@" --with-mpc="$MPC"
../configure \
    --prefix="$workdir/toolchain-$arch" \
    --target="$target" \
    --disable-shared \
    --disable-libgcov \
    --disable-libgomp \
    --disable-multilib \
    --disable-nls \
    --with-system-zlib \
    --enable-languages=c \
    "$@"
make -j"$ncpus" all-gcc
make -j"$ncpus" install-strip-gcc
cd ../..

cd "mingw-w64-v$mingw_version/mingw-w64-crt"
./configure \
    --host="$target" \
    --prefix="$workdir/toolchain-$arch/$target" \
    --with-default-win32-winnt="$winnt" \
    --with-default-msvcrt="$crt"
make -j1
make -j1 install
cd ../..
rm -rf "mingw-w64-v$mingw_version" &

cd "gcc-$gcc_version/build"
make -j"$ncpus"
make -j"$ncpus" install-strip
cd ../..
rm -rf "gcc-$gcc_version" &

case $arch in
    (i?86)
        sdl1_version='39e1580a7d2f8c09521338108c2a94019e37798e'
        rm -rf SDL-1.2-*
        wget -O- "https://github.com/libsdl-org/SDL-1.2/archive/$sdl1_version.tar.gz" | tar -xz

        cd "SDL-1.2-$sdl1_version"
        ./configure \
            --host="$target" \
            --prefix="$workdir/toolchain-$arch/$target" \
            --disable-shared \
            --disable-stdio-redirect \
            --disable-threads \
            CFLAGS='-O3 -DNDEBUG -fomit-frame-pointer -mtune=i686'
        make -j"$ncpus"
        make -j"$ncpus" install
        cd ..
        rm -rf "SDL-1.2-$sdl1_version" &
    ;;
    (x86_64|arm64|aarch64)
        sdl2_version='2.32.10'
        rm -rf SDL-*
        wget -O- "https://github.com/libsdl-org/SDL/archive/refs/tags/release-$sdl2_version.tar.gz" | tar -xz

        cd "SDL-release-$sdl2_version"
        ./configure \
            --host="$target" \
            --prefix="$workdir/toolchain-$arch/$target" \
            --disable-shared \
            CFLAGS='-O3 -DNDEBUG -fomit-frame-pointer'
        make -j"$ncpus"
        make -j"$ncpus" install
        cd ..
        rm -rf "SDL-release-$sdl2_version" &
    ;;
esac

ffmpeg_version=n9.0.2
wget -O- "https://github.com/FFmpeg/FFmpeg/archive/$ffmpeg_version.tar.gz" | tar -xz
cd "FFmpeg-$ffmpeg_version"

case $arch in
    i?86)
        extra_cflags="-mtune=i686"
        patch -p1 < "$platformdir/ffmpeg-crtdll.patch"
        ;;
    x86_64)
        extra_cflags=""
    ;;
esac

./configure \
  --prefix="$workdir/toolchain-$arch/$target" \
  --enable-cross-compile \
  --target-os=mingw32 \
  --arch="$ffmpeg_arch" \
  --cc="$target-gcc" \
  --ar="$target-gcc-ar" \
  --ranlib="$target-gcc-ranlib" \
  --extra-cflags="-O3 -DNDEBUG -fomit-frame-pointer $extra_cflags" \
  --extra-ldflags="-O3 -DNDEBUG -fomit-frame-pointer $extra_cflags" \
  --enable-lto \
  --enable-static \
  --disable-shared \
  --disable-programs \
  --disable-doc \
  --disable-everything \
  --enable-avcodec \
  --enable-avformat \
  --enable-swresample \
  --enable-swscale \
  --enable-decoder=h264,aac \
  --enable-parser=h264,aac \
  --enable-demuxer=mov,aac,h264 \
  --enable-muxer=mp4,aac,m4v \
  --enable-protocol=file \
  --disable-autodetect \
  --disable-iconv
make -j"$ncpus"
make -j"$ncpus" install
cd ..
rm -rf "FFmpeg-$ffmpeg_version" &

printf '%s' "$toolchainver" > "toolchain-$arch/toolchainver"
wait
